package at.kaindorf.linhard.exa_105_airlinereservationsystem.tests;

import org.junit.Test;

public class AirlineTest {

    @Test
    public void test() {

    }
}
