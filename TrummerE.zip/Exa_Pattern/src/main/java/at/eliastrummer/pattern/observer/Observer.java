package at.eliastrummer.pattern.observer;

public interface Observer {
    void update(String data);
}