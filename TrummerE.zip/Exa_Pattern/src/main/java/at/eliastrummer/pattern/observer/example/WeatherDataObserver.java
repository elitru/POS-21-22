package at.eliastrummer.pattern.observer.example;

public interface WeatherDataObserver {
    void update(WeatherData weatherdata);
}
