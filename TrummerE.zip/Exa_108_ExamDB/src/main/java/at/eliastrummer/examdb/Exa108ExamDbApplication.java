package at.eliastrummer.examdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exa108ExamDbApplication {

    public static void main(String[] args) {
        SpringApplication.run(Exa108ExamDbApplication.class, args);
    }

}
