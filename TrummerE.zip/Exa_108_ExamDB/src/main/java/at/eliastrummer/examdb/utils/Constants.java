package at.eliastrummer.examdb.utils;

import java.time.format.DateTimeFormatter;

public class Constants {
    public static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("dd.MM.yyyy");
}
