package at.eliastrummer.examdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exa108ExamDbApplicationTests {

    @Test
    void contextLoads() {
    }

}
